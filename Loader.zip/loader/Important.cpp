ENGLISH 

⚠️ NOTE ⚠️  
These files are without bypass lib ❌  
Do not use them directly ⚡  

👉 Add your own lib (with bypass)  
in this folder with the same name ➝ `libbgmi.so`  

If you don’t know how to build a lib, watch this video 👇👇  
📺 https://youtu.be/u-LnEVKmjkM?si=X5YOaKa8CEUyRKF4  
📺 https://youtu.be/u-LnEVKmjkM?si=X5YOaKa8CEUyRKF4

HINDI 

⚠️ NOTE ⚠️  

Ye files without bypass lib hain ❌  
Inko directly use mat karna ⚡  

👉 Apni khud ki lib (with bypass) ko  
is folder me add karo same name se ➝ `libbgmi.so`  

Agar build karna nahi aata hai, to ye video dekh lo 👇👇  
📺 https://youtu.be/u-LnEVKmjkM?si=X5YOaKa8CEUyRKF4  
📺 https://youtu.be/u-LnEVKmjkM?si=X5YOaKa8CEUyRKF4

